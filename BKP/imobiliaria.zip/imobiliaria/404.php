<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
	<title>404</title>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
    </head>
    <body>
    <title>Ooops</title>
    <br /><br /><br />
    <center>
	<h1>Ooops</h1>
	<img src="application/images/default/404.jpg" />
	<h1>Parece que o sistema quebrou!</h1>
    </center>
</body>
</html>
