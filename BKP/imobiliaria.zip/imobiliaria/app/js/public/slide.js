$(function() {
    $('#dg-container').gallery({
        autoplay:true,
        interval:3000
    });
});