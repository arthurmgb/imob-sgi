<?php
/*
 * @author Rafael Clares <rafael@clares.com>
 * @version 3.0 <11/2013>
 * www.clares.com.br
*/
$databases = array(
    # MYSQL
    'default' => array
        (
        'driver' => 'mysql',
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => 'supergui_imob',
        'user' => 'supergui_admin',
        'password' => 'P@ssw0rd90',
        'emailAdmin' => 'webpatos@gmail.com'// email para receber mensagens do chat
    )
);

/* end file */
