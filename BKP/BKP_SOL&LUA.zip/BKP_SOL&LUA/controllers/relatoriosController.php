<?php
class relatoriosController extends Controller {

 	private $dados = array(
        'menu_ativo' => 'finaceiro'
    );

	public function __construct() {
		parent::__construct();
		$this->user = new Usuarios();
		if(!$this->user->checkLogin()) {
			header("Location: ".BASE_URL."login");
			exit;
		}   
	}

	public function financeiro() {
		$dados = $this->dados;
		
		$config = new Config;
		$caixaHelper = new CaixaHelper;

		$dados['empresa'] = $config->getEmpresa();
		$dados['rows'] = $caixaHelper->relatorio();

 		$this->loadView('relatorios/financeiro', $dados);
	}
}