 <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Imóveis
      <small>Sistema de Gerenciamento Imobiliario</small>
    </h1>
    <!-- search form -->
    <div class="sidebar-form">
      <div class="input-group">
        <input type="search" name="q" autofocus autocomplete="off" onkeyup="buscar_imoveis(this)" class="form-control" placeholder="Buscar pelo bairro ou endereço">
        <span class="input-group-btn">
          <button type="button" name="search" id="search-btn" class="btn btn-flat">
            <i class="fa fa-search"></i>
          </button>
        </span>
      </div>
    </div>
    <!-- /.search form -->
  </section>

  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">Imóveis</h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body table-responsive">
            <table id="example2" class="table table-bordered table-hover">
              <thead>
                <tr>
                  <th>#COD</th>
                  <th>Tipo</th>
                  <th>Endereço</th>
                  <th>Bairro</th>
                  <th>Cidade</th>
                  <th>Valor</th>
                  <th>Finalidade</th>
                  <th>Ações</th>
                </tr>
              </thead>
                <?php foreach ($imob as $imovel):
                $highligthers = array(
                  1 => '',
                  2 => 'danger',
                  3 => 'success'
                );
                ?>
                <tr class="<?php $highlight = $imovel['status'];echo $highligthers[$highlight]; ?>">
                  <td><?php echo $imovel['referencia'];?></td>
                  <td><?php echo $imovel['tipo']; ?></td>
                  <td><?php echo $imovel['endereco']; ?></td>
                  <td><?php echo $imovel['bairro']; ?></td>
                  <td><?php echo $imovel['cidade']; ?></td>
                  <td>R$ <?php echo number_format($imovel['valor'],2,",",".");?></td>
                  <td><?php echo ($imovel['finalidade']=='1') ? 'Aluguel':'Venda'; ?></td>
                  <td>
                    <a href="<?php echo BASE_URL ;?>imovel/ver/<?php echo $imovel['id'];?>" title="Ver" ><i class="fa fa-eye fa-1x fa-border"></i></a>
                    <a href="<?php echo BASE_URL ;?>imovel/editar/<?php echo $imovel['id'];?>" title="Editar" style="margin:0 10px;"><i class="fa fa-file-text fa-1x fa-border"></i></a>
                    <a href="#" onclick="confirm('Tem certeza que deseja apagar?') ? window.location.href='<?php echo BASE_URL.'imovel/del/'.$imovel['id'];?>':''" title="Excluir" ><i class="fa fa-trash fa-1x fa-border"></i></a>
                  </td>
                </tr>
                <?php endforeach ; ?>
            </table>
              
                <div class="dataTables_paginate paging_simple_numbers" id="example2_paginate">
                  <ul class="pagination" style="float:right">
                    <?php
                      $conta = ceil($totalImoveis / $limitImoveis);
                      
                      for($q=1;$q<=$conta;$q++): ?>
                       <li class="paginate_button">   
                      <a href="<?php echo BASE_URL;?>imovel/listar?p=<?php echo $q; ?>" aria-controls="example2"><?php echo $q; ?></a>
                    </li>
                    <?php endfor; ?>
                  </ul>
              </div>
              

          </div>

          <!-- /.box-body -->
        </div>
      </div>
    </div>
  </section>  
  
</div>
