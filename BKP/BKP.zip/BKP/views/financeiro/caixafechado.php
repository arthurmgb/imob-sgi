<section class="content">
 <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header" style="display: flex; justify-content: space-between">
    <h1>
      CAIXA FECHADO
      <small>Sistema de Gerenciamento Imobiliário</small>
    </h1>
  </section>
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box" style="padding-bottom: 20px">
          <h3 style="font-weight: normal; font-size: 30; text-align: center">O CAIXA JA FOI ENCERRADO</h3>
          <a style="display: block;width: 100px;margin: 0 auto;margin-top: 20px" href="#" class="btn btn-primary" onclick="confirm('Tem certeza que deseja reabrir o caixa?')?window.location.href=BASE_URL+'financeiro/reabrircaixa':'';">REABRIR</a>
        </div>
      </div>
    </div>
  </section>  
 </div>
</section>
