 <div class="content-wrapper">
   
  <!-- Main content -->
  <section class="content"  >
    <div class="error-page" style= "margin-top: 10%;">
      <h2 class="headline text-yellow" style="margin: 0;padding: 0; line-height: 1; font-size: 90px;"> 404</h2>

      <div class="error-content">
        <h3><i class="fa fa-warning text-yellow"></i> Oops! Pagina não encontrada.</h3>
        <p>
          Não foi possível encontrar a página que você estava procurando.
          Você pode tentar <a href="#">voltar para home</a> ou pode realizar uma pesquisa.
        </p>
      </div>
      <!-- /.error-content -->
    </div>
    <!-- /.error-page -->
  </section>
    
</div>
